start, end = 1371085, 1371134

def isPrime( x ):
  d = 2
  while d*d <= x:
    if x % d == 0:
      return False
    d += 1
  return True

count = 0
for x in range( start, end+1 ):
  if isPrime( x ):
    count += 1
    print( count, x )

