# Автор: А.Н. Носкин

with open("24-5.txt") as F:
  s = F.readline() # считали строку


print(s.count("()")) # кол-во пар





